/* global cordova, CameraPreview, device */
(function () {
  "use strict";

  var TEST = {
    PREVIEW_BEFORE_MS: 4000,
    RECORD_MS: 30000,
    PREVIEW_AFTER_MS: 5000,
    FINALIZE_MS: 3000,
    SNAPSHOT_EVERY_MS: 1000,
    REC_PROBE_TIMES_MS: [5000, 15000, 25000],
    SNAPSHOT_QUALITY: 70,
    VIDEO_WIDTH: 1280,
    VIDEO_HEIGHT: 720,
    VIDEO_QUALITY: 85,
    SNAPSHOT_CALLBACK_TIMEOUT_MS: 2500
  };
  TEST.TOTAL_MS = TEST.PREVIEW_BEFORE_MS + TEST.RECORD_MS + TEST.PREVIEW_AFTER_MS + TEST.FINALIZE_MS;

  var state = {
    running: false,
    startedAt: null,
    finishedAt: null,
    previewStarted: false,
    recording: false,
    videoPath: "",
    snapshotOk: 0,
    snapshotKo: 0,
    snapshotAttempts: 0,
    snapshotNoCallback: 0,
    pendingSnapshots: {},
    snapshotBefore: null,
    snapshotAfter: null,
    errors: [],
    log: [],
    countdownTimer: null,
    snapshotTimer: null
  };

  var el = {};
  document.addEventListener("deviceready", onDeviceReady, false);

  function onDeviceReady() {
    bindElements();
    bindActions();
    setDeviceLine();
    log("deviceready");

    if (!window.CameraPreview) {
      failInitialization("CameraPreview absent");
      return;
    }

    setReady(true);
    setStatus("Prêt");
    setStep("Preview plein écran sous l’UI → snapshot témoin → REC 30 s + 3 captures PixelCopy → snapshot témoin.");
    setCountdown(TEST.TOTAL_MS);
  }

  function bindElements() {
    [
      "deviceLine","readyBadge","previewShell","previewPlaceholder","statusText","countdown","progressBar",
      "stepText","testButton","liveStats","snapOk","snapKo","snapPending","resultCard","resultTitle",
      "resultBody","exportButton","rerunButton","technicalLog"
    ].forEach(function(id){ el[id]=document.getElementById(id); });
  }

  function bindActions() {
    el.testButton.addEventListener("click", runTest);
    el.rerunButton.addEventListener("click", runTest);
    el.exportButton.addEventListener("click", exportDiagnostic);
  }

  function setDeviceLine() {
    if (window.device) {
      el.deviceLine.textContent =
        (device.manufacturer || "") + " " + (device.model || "") +
        " · Android " + (device.version || "?") +
        " · SDK " + (device.sdkVersion || "?");
    } else {
      el.deviceLine.textContent = "Android · informations appareil indisponibles";
    }
  }

  function setReady(ok) {
    el.testButton.disabled = !ok;
    el.readyBadge.textContent = ok ? "PRÊT" : "ERREUR";
    el.readyBadge.className = "badge " + (ok ? "badge-ok" : "badge-ko");
  }

  function setStatus(text){ el.statusText.textContent=text; }
  function setStep(text){ el.stepText.textContent=text; }

  function setCountdown(ms) {
    var sec = Math.max(0, Math.ceil(ms / 1000));
    var min = Math.floor(sec / 60);
    var rem = sec % 60;
    el.countdown.textContent = String(min).padStart(2,"0")+":"+String(rem).padStart(2,"0");
  }

  function updateProgress() {
    if (!state.startedAt || !state.running) return;
    var elapsed = Date.now() - state.startedAt;
    var remaining = Math.max(0, TEST.TOTAL_MS - elapsed);
    var pct = Math.min(100, (elapsed / TEST.TOTAL_MS) * 100);
    setCountdown(remaining);
    el.progressBar.style.width = pct.toFixed(1) + "%";
  }

  function resetRun() {
    stopTimers();
    state.running=false;
    state.startedAt=null;
    state.finishedAt=null;
    state.previewStarted=false;
    state.recording=false;
    state.videoPath="";
    state.snapshotOk=0;
    state.snapshotKo=0;
    state.snapshotAttempts=0;
    state.snapshotNoCallback=0;
    state.pendingSnapshots={};
    state.snapshotBefore=null;
    state.snapshotAfter=null;
    state.pixelCopyProbes=[];
    state.errors=[];
    state.log=[];

    el.liveStats.classList.add("hidden");
    el.resultCard.classList.add("hidden");
    el.progressBar.style.width="0%";
    setCountdown(TEST.TOTAL_MS);
    refreshSnapshotStats();
  }

  function runTest() {
    if (state.running) return;
    resetRun();

    state.running=true;
    state.startedAt=Date.now();

    el.testButton.disabled=true;
    el.rerunButton.disabled=true;
    el.exportButton.disabled=true;
    el.liveStats.classList.remove("hidden");
    el.readyBadge.textContent="TEST";
    el.readyBadge.className="badge badge-run";

    setStatus("Test en cours");
    setStep("Étape 1/5 — Preview AVANT enregistrement (4 s)");
    state.countdownTimer=setInterval(updateProgress,250);
    updateProgress();

    log("TEST début");

    startPreview()
      .then(function(){ return wait(TEST.PREVIEW_BEFORE_MS); })
      .then(function(){
        setStep("Étape 2/5 — Snapshot témoin AVANT enregistrement");
        return captureWitnessSnapshot("before");
      })
      .then(function(){
        setStep("Étape 3/5 — REC 720p + PixelCopy à 5 s, 15 s et 25 s");
        return startRecording();
      })
      .then(function(){
        startSnapshotLoop();
        return wait(TEST.RECORD_MS);
      })
      .then(function(){
        stopSnapshotLoop();
        setStep("Étape 4/5 — Arrêt REC, preview toujours visible");
        return stopRecording();
      })
      .then(function(){
        return wait(TEST.PREVIEW_AFTER_MS);
      })
      .then(function(){
        setStep("Étape 5/5 — Snapshot témoin APRÈS enregistrement");
        return captureWitnessSnapshot("after");
      })
      .then(function(){ return wait(TEST.FINALIZE_MS); })
      .then(function(){ return stopPreview(); })
      .then(function(){ finishTest(true); })
      .catch(function(err){
        state.errors.push(String(err && err.message ? err.message : err));
        log("TEST échec " + stringify(err));
        stopSnapshotLoop();

        Promise.resolve()
          .then(function(){ return state.recording ? stopRecording().catch(function(){}) : null; })
          .then(function(){ return state.previewStarted ? stopPreview().catch(function(){}) : null; })
          .then(function(){ finishTest(false); });
      });
  }

  function startPreview() {
    return new Promise(function(resolve,reject){
      var options={
        x:0,
        y:0,
        width:Math.round(window.innerWidth || window.screen.width),
        height:Math.round(window.innerHeight || window.screen.height),
        camera:CameraPreview.CAMERA_DIRECTION ? CameraPreview.CAMERA_DIRECTION.BACK : "back",
        toBack:true,
        tapPhoto:false,
        tapFocus:false,
        previewDrag:false,
        storeToFile:false
      };

      log("Camera preview START " + stringify(options));
      CameraPreview.startCamera(
        options,
        function(result){
          state.previewStarted=true;
          el.previewPlaceholder.classList.add("hidden");
          log("Camera preview OK " + stringify(result));
          resolve(result);
        },
        function(err){
          log("Camera preview KO " + stringify(err));
          reject(new Error("Impossible de démarrer la preview: "+stringify(err)));
        }
      );
    });
  }

  function stopPreview() {
    return new Promise(function(resolve){
      if (!state.previewStarted) { resolve(); return; }
      CameraPreview.stopCamera(
        function(result){
          state.previewStarted=false;
          el.previewPlaceholder.classList.remove("hidden");
          log("Camera preview STOP OK "+stringify(result));
          resolve(result);
        },
        function(err){
          state.previewStarted=false;
          el.previewPlaceholder.classList.remove("hidden");
          log("Camera preview STOP KO "+stringify(err));
          resolve();
        }
      );
    });
  }

  function startRecording() {
    return new Promise(function(resolve,reject){
      var options={
        cameraDirection:CameraPreview.CAMERA_DIRECTION ? CameraPreview.CAMERA_DIRECTION.BACK : "back",
        width:TEST.VIDEO_WIDTH,
        height:TEST.VIDEO_HEIGHT,
        quality:TEST.VIDEO_QUALITY,
        withFlash:false
      };
      log("REC start "+stringify(options));
      CameraPreview.startRecordVideo(
        options,
        function(result){
          state.recording=true;
          log("REC start OK "+stringify(result));
          resolve(result);
        },
        function(err){
          log("REC start KO "+stringify(err));
          reject(new Error("Impossible de démarrer l'enregistrement: "+stringify(err)));
        }
      );
    });
  }

  function stopRecording() {
    return new Promise(function(resolve,reject){
      if (!state.recording) { resolve(""); return; }
      log("REC stop");
      CameraPreview.stopRecordVideo(
        function(filePath){
          state.recording=false;
          state.videoPath=typeof filePath==="string" ? filePath : stringify(filePath);
          log("REC stop OK "+stringify(filePath));
          resolve(filePath);
        },
        function(err){
          state.recording=false;
          log("REC stop KO "+stringify(err));
          reject(new Error("Impossible d'arrêter l'enregistrement: "+stringify(err)));
        }
      );
    });
  }

  function captureWitnessSnapshot(which) {
    return new Promise(function(resolve){
      var settled=false;
      var timeout=setTimeout(function(){
        if (settled) return;
        settled=true;
        var obj={ status:"no_callback", data:null, dataType:null, length:0 };
        if (which==="before") state.snapshotBefore=obj;
        else state.snapshotAfter=obj;
        log("SNAP "+which.toUpperCase()+" sans callback");
        resolve(obj);
      }, TEST.SNAPSHOT_CALLBACK_TIMEOUT_MS);

      CameraPreview.takeSnapshot(
        {quality:TEST.SNAPSHOT_QUALITY},
        function(data){
          if (settled) return;
          settled=true;
          clearTimeout(timeout);
          var obj=snapshotObject("ok",data);
          if (which==="before") state.snapshotBefore=obj;
          else state.snapshotAfter=obj;
          log("SNAP "+which.toUpperCase()+" OK type="+obj.dataType+" length="+obj.length);
          resolve(obj);
        },
        function(err){
          if (settled) return;
          settled=true;
          clearTimeout(timeout);
          var obj={ status:"error", data:null, dataType:null, length:0, error:stringify(err) };
          if (which==="before") state.snapshotBefore=obj;
          else state.snapshotAfter=obj;
          log("SNAP "+which.toUpperCase()+" KO "+stringify(err));
          resolve(obj);
        }
      );
    });
  }

  function normalizeSnapshotData(data) {
    var raw = data;
    if (Array.isArray(data) && data.length > 0) raw = data[0];

    var base64 = null;
    if (typeof raw === "string") {
      if (raw.indexOf("data:image/") === 0) {
        var comma = raw.indexOf(",");
        base64 = comma >= 0 ? raw.substring(comma + 1) : raw;
      } else {
        base64 = raw;
      }
    }

    return {
      originalType: Array.isArray(data) ? "array" : typeof data,
      arrayLength: Array.isArray(data) ? data.length : null,
      rawType: typeof raw,
      length: typeof base64 === "string" ? base64.length : 0,
      base64: base64
    };
  }

  function snapshotObject(status,data){
    var normalized = normalizeSnapshotData(data);
    return {
      status:status,
      dataType:normalized.originalType,
      arrayLength:normalized.arrayLength,
      rawType:normalized.rawType,
      length:normalized.length,
      data:normalized.base64
    };
  }

  function startSnapshotLoop() {
    state.snapshotAttempts = 0;
    state.snapshotOk = 0;
    state.snapshotKo = 0;
    state.snapshotNoCallback = 0;
    state.recProbeTimers = [];

    TEST.REC_PROBE_TIMES_MS.forEach(function(delayMs, index) {
      var timer = setTimeout(function() {
        takeOneSnapshot(index + 1, delayMs);
      }, delayMs);
      state.recProbeTimers.push(timer);
    });
  }

  function stopSnapshotLoop() {
    if (state.snapshotTimer) {
      clearInterval(state.snapshotTimer);
      state.snapshotTimer=null;
    }
    if (state.recProbeTimers) {
      state.recProbeTimers.forEach(function(timer){ clearTimeout(timer); });
      state.recProbeTimers=[];
    }
  }

  function takeOneSnapshot(id, scheduledMs) {
    if (!state.running || !state.recording) return;

    state.snapshotAttempts++;
    state.pendingSnapshots[id]=true;
    refreshSnapshotStats();

    var calledAt=Date.now();
    log("PIXELCOPY probe "+id+" appel à +"+scheduledMs+" ms");

    var settled=false;
    var timeout=setTimeout(function(){
      if (settled) return;
      settled=true;
      if (state.pendingSnapshots[id]) delete state.pendingSnapshots[id];
      state.snapshotNoCallback++;
      state.pixelCopyProbes.push({id:id,scheduledMs:scheduledMs,status:"no_callback",elapsedMs:Date.now()-calledAt,base64:null});
      log("PIXELCOPY probe "+id+" SANS CALLBACK après "+TEST.SNAPSHOT_CALLBACK_TIMEOUT_MS+" ms");
      refreshSnapshotStats();
    },TEST.SNAPSHOT_CALLBACK_TIMEOUT_MS);

    if (typeof CameraPreview.capturePreviewSurface !== "function") {
      clearTimeout(timeout);
      settled=true;
      if (state.pendingSnapshots[id]) delete state.pendingSnapshots[id];
      state.snapshotKo++;
      state.pixelCopyProbes.push({id:id,scheduledMs:scheduledMs,status:"method_missing",elapsedMs:0,base64:null});
      log("PIXELCOPY probe "+id+" KO: capturePreviewSurface() absent - patch natif non appliqué");
      refreshSnapshotStats();
      return;
    }

    CameraPreview.capturePreviewSurface(
      {quality:TEST.SNAPSHOT_QUALITY},
      function(data){
        if (settled) { log("PIXELCOPY probe "+id+" callback SUCCESS tardif après "+(Date.now()-calledAt)+" ms"); return; }
        settled=true;
        clearTimeout(timeout);
        if (state.pendingSnapshots[id]) delete state.pendingSnapshots[id];
        var normalized=normalizeSnapshotData(data);
        state.snapshotOk++;
        state.pixelCopyProbes.push({id:id,scheduledMs:scheduledMs,status:"ok",elapsedMs:Date.now()-calledAt,length:normalized.length,base64:normalized.base64});
        log("PIXELCOPY probe "+id+" OK après "+(Date.now()-calledAt)+" ms, base64="+normalized.length+" caractères");
        refreshSnapshotStats();
      },
      function(err){
        if (settled) { log("PIXELCOPY probe "+id+" callback ERROR tardif après "+(Date.now()-calledAt)+" ms: "+stringify(err)); return; }
        settled=true;
        clearTimeout(timeout);
        if (state.pendingSnapshots[id]) delete state.pendingSnapshots[id];
        state.snapshotKo++;
        state.pixelCopyProbes.push({id:id,scheduledMs:scheduledMs,status:"error",elapsedMs:Date.now()-calledAt,error:stringify(err),base64:null});
        log("PIXELCOPY probe "+id+" KO après "+(Date.now()-calledAt)+" ms: "+stringify(err));
        refreshSnapshotStats();
      }
    );
  }

  function refreshSnapshotStats() {
    if (!el.snapOk) return;
    el.snapOk.textContent=state.snapshotOk;
    el.snapKo.textContent=state.snapshotKo;
    el.snapPending.textContent=state.snapshotNoCallback;
  }

  function finishTest(pipelineOk) {
    state.running=false;
    state.finishedAt=Date.now();
    stopTimers();
    el.progressBar.style.width="100%";
    setCountdown(0);

    var videoOk=!!state.videoPath;
    var witnessBeforeOk=state.snapshotBefore && state.snapshotBefore.status==="ok";
    var witnessAfterOk=state.snapshotAfter && state.snapshotAfter.status==="ok";
    var overallOk=pipelineOk && videoOk && witnessBeforeOk && witnessAfterOk;

    setStatus(overallOk ? "Test terminé" : "Test incomplet");
    setStep("Le diagnostic contient les snapshots témoins avant/après s'ils ont été renvoyés par le plugin.");

    el.readyBadge.textContent=overallOk ? "OK" : "À VOIR";
    el.readyBadge.className="badge "+(overallOk ? "badge-ok" : "badge-ko");
    el.resultTitle.textContent=overallOk ? "Test terminé" : "Test à analyser";

    var duration=state.startedAt && state.finishedAt
      ? ((state.finishedAt-state.startedAt)/1000).toFixed(1)+" s" : "—";

    el.resultBody.innerHTML=
      '<div class="result-grid">'+
      '<div class="label">Preview avant</div><div class="value">'+(witnessBeforeOk ? "snapshot OK" : witnessStatus(state.snapshotBefore))+'</div>'+
      '<div class="label">Vidéo</div><div class="value">'+(videoOk ? "OK" : "KO")+'</div>'+
      '<div class="label">PixelCopy pendant REC</div><div class="value">'+state.snapshotOk+' OK / '+state.snapshotKo+' KO / '+state.snapshotNoCallback+' sans callback</div>'+
      '<div class="label">Preview après</div><div class="value">'+(witnessAfterOk ? "snapshot OK" : witnessStatus(state.snapshotAfter))+'</div>'+
      '<div class="label">Durée</div><div class="value">'+duration+'</div>'+
      '<div class="label">Fichier vidéo</div><div class="value">'+escapeHtml(state.videoPath || "—")+'</div>'+
      '</div>';

    el.resultCard.classList.remove("hidden");
    el.testButton.disabled=false;
    el.rerunButton.disabled=false;
    el.exportButton.disabled=false;

    log("TEST fin video="+videoOk+
        " before="+witnessStatus(state.snapshotBefore)+
        " recOK="+state.snapshotOk+
        " recKO="+state.snapshotKo+
        " recNoCb="+state.snapshotNoCallback+
        " after="+witnessStatus(state.snapshotAfter));

    renderTechnicalLog();
  }

  function witnessStatus(obj){
    if (!obj) return "—";
    return obj.status || "—";
  }

  function stopTimers() {
    if (state.countdownTimer) {
      clearInterval(state.countdownTimer);
      state.countdownTimer=null;
    }
    stopSnapshotLoop();
  }

  function failInitialization(message){
    setReady(false);
    setStatus("Impossible de tester");
    setStep(message);
    log("INIT KO "+message);
  }

  function buildDiagnostic() {
    return {
      exportedAt:new Date().toISOString(),
      app:{name:"MultiCam Camera Lab",version:"0.9.1-pixelcopy",platform:"Android"},
      device:window.device ? {
        manufacturer:device.manufacturer || null,
        model:device.model || null,
        version:device.version || null,
        sdkVersion:device.sdkVersion || null,
        uuid:device.uuid || null,
        cordova:device.cordova || null
      } : null,
      plugin:{
        cameraPreview:!!window.CameraPreview,
        source:"https://github.com/cordova-plugin-camera-preview/cordova-plugin-camera-preview.git#master"
      },
      test:{
        totalExpectedSeconds:Math.round(TEST.TOTAL_MS/1000),
        previewBefore:{
          durationMs:TEST.PREVIEW_BEFORE_MS,
          witnessSnapshot:state.snapshotBefore
        },
        video:{
          width:TEST.VIDEO_WIDTH,
          height:TEST.VIDEO_HEIGHT,
          quality:TEST.VIDEO_QUALITY,
          file:state.videoPath || null
        },
        snapshotsDuringRecording:{
          strategy:"pixelcopy_surfaceview",
          probeTimesMs:TEST.REC_PROBE_TIMES_MS.slice(),
          callbackTimeoutMs:TEST.SNAPSHOT_CALLBACK_TIMEOUT_MS,
          probes:state.pixelCopyProbes.slice(),
          expected:TEST.REC_PROBE_TIMES_MS.length,
          attempted:state.snapshotAttempts,
          ok:state.snapshotOk,
          ko:state.snapshotKo,
          noCallback:state.snapshotNoCallback,
          quality:TEST.SNAPSHOT_QUALITY
        },
        previewAfter:{
          durationMs:TEST.PREVIEW_AFTER_MS,
          witnessSnapshot:state.snapshotAfter
        },
        startedAt:state.startedAt ? new Date(state.startedAt).toISOString() : null,
        finishedAt:state.finishedAt ? new Date(state.finishedAt).toISOString() : null,
        errors:state.errors.slice()
      },
      log:state.log.slice()
    };
  }

  function exportDiagnostic() {
    var diagnostic=buildDiagnostic();
    var text=JSON.stringify(diagnostic,null,2);
    var filename="multicam-camera-diagnostic-"+new Date().toISOString().replace(/[:.]/g,"-")+".json";

    if (window.cordova && cordova.file && window.resolveLocalFileSystemURL &&
        window.plugins && window.plugins.socialsharing) {
      window.resolveLocalFileSystemURL(
        cordova.file.cacheDirectory,
        function(dirEntry){
          dirEntry.getFile(filename,{create:true,exclusive:false},function(fileEntry){
            fileEntry.createWriter(function(writer){
              writer.onwriteend=function(){
                window.plugins.socialsharing.shareWithOptions(
                  {subject:"MultiCam Camera diagnostic",files:[fileEntry.nativeURL]},
                  function(){ log("EXPORT partage OK"); },
                  function(err){ log("EXPORT partage KO "+stringify(err)); fallbackShare(text); }
                );
              };
              writer.onerror=function(){ fallbackShare(text); };
              writer.write(new Blob([text],{type:"application/json"}));
            },function(){ fallbackShare(text); });
          },function(){ fallbackShare(text); });
        },
        function(){ fallbackShare(text); }
      );
      return;
    }
    fallbackShare(text);
  }

  function fallbackShare(text) {
    if (window.plugins && window.plugins.socialsharing) {
      window.plugins.socialsharing.share(
        text,"MultiCam Camera diagnostic",null,null,
        function(){ log("EXPORT texte OK"); },
        function(err){ log("EXPORT texte KO "+stringify(err)); alert("Impossible d'exporter le diagnostic."); }
      );
    } else if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function(){
        alert("Diagnostic copié dans le presse-papiers.");
      }).catch(function(){ alert(text); });
    } else {
      alert(text);
    }
  }

  function renderTechnicalLog(){ el.technicalLog.textContent=state.log.join("\n"); }

  function log(message){
    var line="["+new Date().toLocaleTimeString("fr-FR",{hour12:false})+"] "+message;
    state.log.push(line);
    if (el.technicalLog) renderTechnicalLog();
    console.log(line);
  }

  function wait(ms){ return new Promise(function(resolve){ setTimeout(resolve,ms); }); }

  function stringify(value){
    if (typeof value==="string") return value;
    try { return JSON.stringify(value); } catch(e) { return String(value); }
  }

  function escapeHtml(value){
    return String(value)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#039;");
  }
})();
