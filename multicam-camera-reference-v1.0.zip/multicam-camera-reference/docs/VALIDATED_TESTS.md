# Tests validés

## Appareil de référence

- Fabricant : samsung
- Modèle : SM-A226B
- Android : 13
- SDK : 33

## Matrice

| Fonction | Résultat | Notes |
|---|---|---|
| Démarrage preview caméra | VALIDÉ | Preview native |
| Preview plein écran sous WebView | VALIDÉ | `toBack:true`, UI transparente |
| Snapshot hors REC | VALIDÉ | JPEG base64 reçu |
| Enregistrement vidéo 1280×720 | VALIDÉ | MP4 produit |
| `takeSnapshot()` pendant REC | INVALIDÉ | Aucun callback |
| PixelCopy preview pendant REC | VALIDÉ | 3/3 probes |
| Snapshot après arrêt REC | VALIDÉ | Ref fonctionne immédiatement |
| Export diagnostic JSON | VALIDÉ | Contient les JPEG base64 |

## Mesures du test PixelCopy final

```json
[
  {
    "id": 1,
    "scheduledMs": 5000,
    "status": "ok",
    "elapsedMs": 127,
    "length": 186908
  },
  {
    "id": 2,
    "scheduledMs": 15000,
    "status": "ok",
    "elapsedMs": 66,
    "length": 134196
  },
  {
    "id": 3,
    "scheduledMs": 25000,
    "status": "ok",
    "elapsedMs": 65,
    "length": 112432
  }
]
```

Séquence du diagnostic :

```text
Preview start
Snapshot BEFORE : OK
REC start : OK
PixelCopy +5 s  : OK
PixelCopy +15 s : OK
PixelCopy +25 s : OK
REC stop : OK
Snapshot AFTER  : OK
Preview stop : OK
```

Le fichier brut correspondant est :
`evidence/validated-pixelcopy-diagnostic.json`.
