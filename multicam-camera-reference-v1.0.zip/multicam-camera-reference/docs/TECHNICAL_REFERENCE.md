# Référence technique caméra Android

## 1. Plugin de base

Le travail est basé sur `cordova-plugin-camera-preview`.

La preview Android est une vue native `SurfaceView`, située hors du DOM HTML.
Le JavaScript contrôle sa position et indique si elle est placée devant ou derrière la WebView.

### Configuration de preview validée

```js
CameraPreview.startCamera({
  x: 0,
  y: 0,
  width: window.innerWidth,
  height: window.innerHeight,
  camera: CameraPreview.CAMERA_DIRECTION.BACK,
  toBack: true,
  tapPhoto: false,
  tapFocus: false,
  previewDrag: false,
  storeToFile: false
});
```

Avec `toBack:true`, la WebView doit être transparente pour laisser voir la preview.

## 2. Enregistrement vidéo

Le chemin `startRecordVideo()` / `stopRecordVideo()` fonctionne.

Configuration de test validée :

```js
CameraPreview.startRecordVideo({
  cameraDirection: CameraPreview.CAMERA_DIRECTION.BACK,
  width: 1280,
  height: 720,
  quality: 85,
  withFlash: false
}, success, error);
```

Le test validé a produit un MP4 pendant que les captures PixelCopy fonctionnaient.

## 3. Snapshot classique

`CameraPreview.takeSnapshot()` fonctionne lorsque le recorder est arrêté.

Le plugin retourne sur cet environnement un payload de type tableau contenant le JPEG base64 :

```js
[
  "/9j/4AAQSkZJRg..."
]
```

La normalisation de référence est donc :

```js
function normalizeSnapshotData(data) {
  var raw = data;
  if (Array.isArray(data) && data.length > 0) raw = data[0];

  var base64 = null;
  if (typeof raw === "string") {
    if (raw.indexOf("data:image/") === 0) {
      var comma = raw.indexOf(",");
      base64 = comma >= 0 ? raw.substring(comma + 1) : raw;
    } else {
      base64 = raw;
    }
  }

  return base64;
}
```

### Limitation validée

Pendant `startRecordVideo()`, `takeSnapshot()` ne renvoie ni succès ni erreur sur
l'appareil testé. Plusieurs stratégies ont été essayées :
- 30 appels, environ 1 Hz ;
- 3 appels isolés à +5 s, +15 s et +25 s.

Résultat : aucun callback pendant le REC.

Cette méthode ne doit donc pas être utilisée pour les images périodiques pendant l'enregistrement.

## 4. Capture PixelCopy pendant REC

Une extension native a été ajoutée :

```js
CameraPreview.capturePreviewSurface(
  { quality: 70 },
  function(base64) {
    // JPEG base64
  },
  function(error) {
    // erreur native
  }
);
```

### Implémentation Android

Le patch :
1. récupère le `SurfaceView` de preview ;
2. crée un `Bitmap` à la taille de la surface ;
3. exécute `PixelCopy.request(surfaceView, bitmap, ...)` ;
4. compresse le bitmap en JPEG ;
5. retourne le JPEG base64 au callback Cordova.

PixelCopy nécessite Android API 24+.

### Pourquoi cette méthode fonctionne pendant le REC

Elle ne sollicite pas une nouvelle image via le callback preview de la caméra.
Elle copie les pixels de la surface native déjà rendue pendant que `MediaRecorder`
continue d'enregistrer.

## 5. API à conserver

### JavaScript

```js
CameraPreview.capturePreviewSurface({ quality: 70 }, success, error);
```

### Contrat succès

Le callback reçoit une chaîne base64 JPEG.

### Contrat erreur

Le callback erreur reçoit un message explicite, notamment :
- API Android trop ancienne ;
- `SurfaceView` absent ;
- dimensions invalides ;
- surface invalide ;
- code d'erreur PixelCopy ;
- erreur d'encodage JPEG.

## 6. Performance observée

Sur le test de référence, les 3 PixelCopy pendant REC ont répondu en environ :
- 127 ms ;
- 66 ms ;
- 65 ms.

Cela valide le principe. Cela ne constitue pas encore une garantie qu'une cadence
élevée ou permanente soit sans impact thermique/CPU/mémoire.

La prochaine cadence fonctionnelle recommandée pour le produit est de commencer
à 1 image/seconde, mesurer, puis réduire la résolution JPEG si nécessaire.
