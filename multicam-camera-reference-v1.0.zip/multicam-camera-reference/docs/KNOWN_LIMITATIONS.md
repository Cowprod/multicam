# Limites connues et décisions

## Validé uniquement sur Android

Le patch PixelCopy est Android-spécifique.
Ne pas extrapoler son fonctionnement à iOS.

## PixelCopy copie la preview

Ce n'est pas une photo pleine résolution issue du capteur.
La résolution et le cadrage correspondent à la surface de preview.

Pour l'usage visé (frame périodique pendant l'enregistrement), c'est un avantage :
- volume plus faible ;
- pas de seconde capture Camera ;
- cohérent avec ce qui est effectivement affiché.

## Ne pas confondre DOM et preview native

La preview ne vit pas dans un `<video>` HTML.
Un élément `<div>` n'est qu'un repère de layout éventuel.

## Cadence 1 Hz

Les tests finaux ont validé 3 captures ponctuelles pendant 30 secondes.
La cadence continue à 1 Hz est la prochaine étape, mais elle n'est pas encore
documentée ici comme validée.

Un agent ne doit donc pas écrire « 1 Hz validé » avant un test spécifique.

## Rotation / orientation

Les images de snapshot/preview ont été exploitables, mais aucun contrat définitif
de rotation/crop n'est figé ici pour l'application finale.

## Réinstallation du plugin

Le patch modifie les fichiers du plugin installé.
Une réinstallation peut écraser les modifications. Toujours conserver et rejouer :

```bash
python3 pixelcopy-patch/apply_pixelcopy_patch.py .
```

À terme, la solution propre sera soit :
- un fork/version privée du plugin ;
- soit un plugin Cordova dédié contenant cette fonctionnalité.

## Dépendances Cordova observées

Lors de la recréation de la plateforme Android, un ancien
`cordova-plugin-add-swift-support` a nécessité des dépendances npm (`xcode`,
puis ses dépendances internes). Cela est indépendant de PixelCopy.

Ne pas modifier les dépendances globales ou lancer `npm audit fix --force`
dans le seul but de résoudre la caméra.
