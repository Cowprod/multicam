# MultiCam Camera — projet de référence

Ce dossier fige les éléments **techniquement validés** lors du POC caméra Android.

Commencer par lire `AGENTS.md`.

## But

La contrainte principale est :

> enregistrer une vidéo tout en récupérant périodiquement une image exploitable.

La solution validée est :

- `cordova-plugin-camera-preview` pour preview + vidéo ;
- patch natif Android `PixelCopy` pour récupérer une frame de la preview pendant le REC.

## Installation du patch dans un projet Cordova existant

Copier `pixelcopy-patch/`, puis depuis la racine du projet :

```bash
python3 pixelcopy-patch/apply_pixelcopy_patch.py .
cordova prepare android
cordova build android
```

Validation :

```bash
grep -R "capturePreviewSurface" platforms/android | head -20
```

## Important

`takeSnapshot()` pendant le REC est une impasse sur l'appareil testé.
Ne pas revenir à cette solution sauf si un changement de plugin/API est volontairement testé.
