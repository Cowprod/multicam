# AGENTS.md — Référence technique MultiCam Android

## Mission

Ce dossier est la **référence validée** pour la partie caméra Android du projet MultiCam.
Un agent de codage doit partir de ces conclusions et éviter de refaire les essais déjà tranchés.

## Règles impératives

1. Ne pas utiliser `CameraPreview.takeSnapshot()` pendant `startRecordVideo()`.
   - Sur l'appareil de référence, les appels pendant le REC restent sans callback.
   - Cette voie est considérée comme invalidée.

2. Pour obtenir une image pendant le REC, utiliser la méthode native ajoutée :
   `CameraPreview.capturePreviewSurface({quality}, success, error)`.
   - Android : `PixelCopy.request(...)` sur le `SurfaceView` de preview.
   - Cette voie est validée avec 3/3 captures réussies pendant un REC 720p.

3. La preview de référence est native et non DOM.
   - Le `div` HTML ne contient pas les pixels caméra.
   - `canvas.drawImage(div)` / html2canvas ne permettent pas de récupérer la preview.
   - La WebView est transparente et la preview native peut être placée dessous avec `toBack:true`.

4. Conserver le patch du plugin dans `pixelcopy-patch/`.
   Après toute réinstallation du plugin / recréation de plateforme Android :
   ```bash
   python3 pixelcopy-patch/apply_pixelcopy_patch.py .
   cordova prepare android
   ```

5. Après un `cordova platform rm android && cordova platform add android`, vérifier la présence du patch :
   ```bash
   grep -R "capturePreviewSurface" platforms/android | head -20
   ```

6. Ne pas considérer le test réussi uniquement parce qu'un callback est renvoyé.
   Pour les captures PixelCopy, vérifier aussi :
   - base64 non vide ;
   - JPEG décodable ;
   - images différentes dans le temps.

## Environnement validé

- Application : `MultiCam Camera Lab`
- Version du lab ayant validé PixelCopy : `0.9.1-pixelcopy`
- Appareil : `samsung SM-A226B`
- Android : `13`
- SDK appareil : `33`
- Build Cordova Android testé ensuite : `cordova-android 15.1.0`
- Target/Compile SDK observé lors du rebuild : `36`

## Chemin validé

```text
Camera
  |
  +--> SurfaceView native de preview
  |       |
  |       +--> PixelCopy --> Bitmap --> JPEG --> Base64
  |
  +--> MediaRecorder --> MP4
```

L'intérêt du chemin PixelCopy est qu'il copie la surface déjà rendue. Il ne demande pas
à l'ancienne API Camera de produire une image supplémentaire pendant l'enregistrement.

## Résultat de validation PixelCopy

[
  {
    "id": 1,
    "scheduledMs": 5000,
    "status": "ok",
    "elapsedMs": 127,
    "length": 186908
  },
  {
    "id": 2,
    "scheduledMs": 15000,
    "status": "ok",
    "elapsedMs": 66,
    "length": 134196
  },
  {
    "id": 3,
    "scheduledMs": 25000,
    "status": "ok",
    "elapsedMs": 65,
    "length": 112432
  }
]

Les 3 probes pendant le REC ont réussi. Le diagnostic source est conservé dans
`evidence/validated-pixelcopy-diagnostic.json`.

## Fichiers de référence

- `www/` : lab fonctionnel servant d'exemple d'intégration JS/UI.
- `pixelcopy-patch/apply_pixelcopy_patch.py` : patch automatique du plugin.
- `docs/TECHNICAL_REFERENCE.md` : architecture et API.
- `docs/VALIDATED_TESTS.md` : résultats validés.
- `docs/KNOWN_LIMITATIONS.md` : limites et décisions.
- `evidence/validated-pixelcopy-diagnostic.json` : preuve brute du test réussi.

## Pour le code produit

Le lab n'est pas l'architecture finale de production.
Réutiliser les mécanismes validés, mais isoler l'accès caméra dans un service/module dédié.
La future logique métier ne doit pas dépendre des éléments UI de ce lab.
