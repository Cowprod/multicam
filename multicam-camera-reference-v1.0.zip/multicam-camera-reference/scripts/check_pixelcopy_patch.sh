#!/usr/bin/env bash
set -e

echo "== PixelCopy reference check =="

if grep -R "capturePreviewSurface" plugins/cordova-plugin-camera-preview >/dev/null 2>&1; then
  echo "OK: plugin source patched"
else
  echo "KO: capturePreviewSurface absent from plugins/"
  exit 1
fi

if grep -R "capturePreviewSurface" platforms/android >/dev/null 2>&1; then
  echo "OK: Android platform contains patch"
else
  echo "KO: capturePreviewSurface absent from platforms/android/"
  exit 2
fi

echo "Reference patch is present."
